# PreCadExplorer

## 説明
PreCadのファイル構造を確認するためのアプリです。

## 使ったライブラリ

- Avalon.Edit
https://github.com/icsharpcode/AvalonEdit
